package com.example.demo.services;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.stereotype.Service;

import com.example.demo.dtos.CPFValidation;

@Service
public class GetCpfService {
    private Integer SMALL_DELAY = 1000;
    private Integer MEDIUM_DELAY = 2500;
    private Duration TIMEOUT = Duration.ofSeconds(10);

    public WebDriver getDriver(){
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");

        return new ChromeDriver(options);
    }

    public CPFValidation validateCpf(String cpf, String birthDate) throws InterruptedException {
        String situation = "";

        WebDriver driver = getDriver();

        driver.get("https://servicos.receita.fazenda.gov.br/Servicos/CPF/ConsultaSituacao/ConsultaPublica.asp");
        Thread.sleep(SMALL_DELAY);

        WebElement inputCpf = driver.findElement(By.id("txtCPF"));
        WebElement inputBirthDate = driver.findElement(By.id("txtDataNascimento"));

        inputCpf.sendKeys(cpf);
        Thread.sleep(SMALL_DELAY);
        inputBirthDate.sendKeys(birthDate);

        new WebDriverWait(driver, TIMEOUT).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//*[@id='hcaptcha']/iframe")));
        Thread.sleep(MEDIUM_DELAY);

        new WebDriverWait(driver, TIMEOUT).until(ExpectedConditions.elementToBeClickable(By.id("checkbox"))).click();
        Thread.sleep(MEDIUM_DELAY);

        driver.switchTo().defaultContent();

        new WebDriverWait(driver, TIMEOUT).until(ExpectedConditions.elementToBeClickable(By.id("id_submit"))).click();
        Thread.sleep(MEDIUM_DELAY);

        try {
            WebElement regularSituation = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div/div/div/div/div/div[1]/div[2]/p/span[4]"));
            situation = regularSituation.getText().contains("REGULAR") ? "REGULAR" : "NÃO REGULAR";
        } catch (NoSuchElementException e) {
            situation = "NÃO REGULAR";
        }

        driver.quit();

        return new CPFValidation(situation, "200");
    }
}
