package com.example.demo.dtos;

import java.time.LocalDate;

public record CPFValidationInput(String cpf, String birthDate) {
}
