package com.example.demo.dtos;

public record CPFValidation (String result, String status) {
}
