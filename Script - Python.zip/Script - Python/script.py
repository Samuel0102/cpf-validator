from selenium import webdriver

from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException 

from time import sleep


def get_browser():
  configuration = Options()
  configuration.add_argument("--headless")

  return webdriver.Chrome(options=configuration)


def check_regular_cpf(cpf: str, birth_date: str) -> bool:
  SMALL_DELAY = 1
  MEDIUM_DELAY = 2.5
  TIMEOUT = 10

  is_regular = False

  browser = get_browser()
  browser.get("https://servicos.receita.fazenda.gov.br/Servicos/CPF/ConsultaSituacao/ConsultaPublica.asp")
  sleep(SMALL_DELAY)

  input_cpf = browser.find_element(By.ID, "txtCPF")
  input_birth_date = browser.find_element(By.ID, "txtDataNascimento")

  input_cpf.send_keys(cpf)
  sleep(SMALL_DELAY)
  input_birth_date.send_keys(birth_date)

  WebDriverWait(browser, TIMEOUT).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//*[@id='hcaptcha']/iframe")))
  sleep(MEDIUM_DELAY)

  WebDriverWait(browser, TIMEOUT).until(EC.element_to_be_clickable((By.ID, "checkbox"))).click()
  sleep(MEDIUM_DELAY)

  browser.switch_to.default_content()

  WebDriverWait(browser, TIMEOUT).until(EC.element_to_be_clickable((By.ID, "id_submit"))).click()
  sleep(MEDIUM_DELAY)

  try:
    regular_situation = browser.find_element(By.XPATH, "/html/body/div[2]/div[2]/div[1]/div/div/div/div/div/div[1]/div[2]/p/span[4]")
    is_regular = "REGULAR" if "REGULAR" in regular_situation.text.upper() else "NÃO REGULAR"

  except NoSuchElementException:
    is_regular = "NÃO REGULAR"

  return is_regular