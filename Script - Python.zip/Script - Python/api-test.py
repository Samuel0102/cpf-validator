import requests
from concurrent.futures import ThreadPoolExecutor
import json
import time
from random import choice

def send_request(url, data):
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, data=json.dumps(data), headers=headers)

    returned = {}
    returned["cpf"] = data["cpf"]
    returned["birthDate"] = data["birthDate"]
    returned["result"] = response.json()["result"]
    returned["status"] = response.json()["status"]

    return returned

url = 'http://localhost:5000/check-cpf'

num_requests = 20

data_array = [{"cpf": "", "birthDate": ""}]

with ThreadPoolExecutor(max_workers=num_requests) as executor:
    start = time.time()
    futures = [executor.submit(send_request, url, choice(data_array)) for _ in range(num_requests)]
    results = [future.result() for future in futures]

    end = time.time()
    print(results)
    
    print("Time spend: " + str(end - start))