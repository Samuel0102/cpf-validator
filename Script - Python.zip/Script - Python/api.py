from flask import Flask, request, jsonify
from script import check_regular_cpf

app = Flask(__name__)
app.config["DEBUG"] = True

@app.route("/check-cpf", methods=["POST"])
def check_cpf():
  body = request.get_json()
  
  result = check_regular_cpf(body["cpf"], body["birthDate"])

  return jsonify({
    "result": result,
    "status": 200
  })

if(__name__ == "__main__"):
  app.run()